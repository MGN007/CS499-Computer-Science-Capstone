package com.example.matthewgarcianievesinventorytracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.util.Base64;

import java.security.SecureRandom;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Database helper class.
 * Handles user accounts and inventory records.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    // Database information
    private static final String DATABASE_NAME = "InventoryTracker.db";
    private static final int DATABASE_VERSION = 1;

    // Enhancement: Added password hashing settings to improve account security.
    private static final int SALT_LENGTH = 16;
    private static final int HASH_LENGTH = 256;
    private static final int PBKDF2_ITERATIONS = 100000;

    // User table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory table
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_ITEM_NUMBER = "item_number";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_QUANTITY = "quantity";

    /**

     * Constructor
     */

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**

     * Creates database tables when app runs for first time.
     */

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_USERNAME + " TEXT UNIQUE, " +
                        COLUMN_PASSWORD + " TEXT)";

        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_ITEM_NUMBER + " TEXT, " +
                        COLUMN_ITEM_NAME + " TEXT, " +
                        COLUMN_QUANTITY + " INTEGER)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    /**

     * Recreates tables if database version changes.
     */

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion,
                          int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);

        onCreate(db);
    }

    /**
     * Adds a new user account.
     */
    public boolean addUser(String username,
                           String password) {

        SQLiteDatabase db = this.getWritableDatabase();

        // Enhancement: Hash the password before storing it in the database.
        String hashedPassword = hashPassword(password);

        if (hashedPassword == null) {
            return false;
        }

        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, hashedPassword);

        long result =
                db.insert(TABLE_USERS, null, values);

        return result != -1;
    }

    /**
     * Enhancement: Checks the username first, then verifies the entered
     * password against the salted PBKDF2 hash stored in the database.
     */
    public boolean checkUser(String username,
                             String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT " + COLUMN_PASSWORD +
                                " FROM " + TABLE_USERS +
                                " WHERE " + COLUMN_USERNAME + "=?",
                        new String[]{username});

        if (cursor.moveToFirst()) {

            String storedPassword = cursor.getString(0);
            cursor.close();

            return verifyPassword(password, storedPassword);
        }

        cursor.close();
        return false;
    }

    /**
     * Enhancement: Creates a salted PBKDF2 hash instead of
     * storing a user's password as plain text.
     */
    private String hashPassword(String password) {

        try {
            SecureRandom secureRandom = new SecureRandom();

            byte[] salt = new byte[SALT_LENGTH];
            secureRandom.nextBytes(salt);

            PBEKeySpec spec =
                    new PBEKeySpec(
                            password.toCharArray(),
                            salt,
                            PBKDF2_ITERATIONS,
                            HASH_LENGTH);

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] hash =
                    factory.generateSecret(spec).getEncoded();

            String saltString =
                    Base64.encodeToString(
                            salt,
                            Base64.NO_WRAP);

            String hashString =
                    Base64.encodeToString(
                            hash,
                            Base64.NO_WRAP);

            return saltString + ":" + hashString;

        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Enhancement: Verifies a login password against the
     * salted PBKDF2 hash stored in the database.
     */
    private boolean verifyPassword(String password, String storedPassword) {

        try {
            String[] parts = storedPassword.split(":");

            if (parts.length != 2) {
                return false;
            }

            byte[] salt =
                    Base64.decode(parts[0], Base64.NO_WRAP);

            byte[] storedHash =
                    Base64.decode(parts[1], Base64.NO_WRAP);

            PBEKeySpec spec =
                    new PBEKeySpec(
                            password.toCharArray(),
                            salt,
                            PBKDF2_ITERATIONS,
                            HASH_LENGTH);

            SecretKeyFactory factory =
                    SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");

            byte[] enteredHash =
                    factory.generateSecret(spec).getEncoded();

            if (enteredHash.length != storedHash.length) {
                return false;
            }

            int difference = 0;

            for (int i = 0; i < enteredHash.length; i++) {
                difference |= enteredHash[i] ^ storedHash[i];
            }

            return difference == 0;

        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Adds a new inventory item to the database.
     */
    public boolean addInventoryItem(String itemNumber,
                                    String itemName,
                                    int quantity) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NUMBER, itemNumber);
        values.put(COLUMN_ITEM_NAME, itemName);
        values.put(COLUMN_QUANTITY, quantity);

        long result =
                db.insert(TABLE_INVENTORY, null, values);

        return result != -1;
    }

    /**

     * Reads all inventory items from the database.
     */
    public Cursor getAllInventoryItems() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY,
                null);
    }

    /**
     * Enhancement: Searches inventory by item number or item name.
     */
    public Cursor searchInventory(String searchText) {

        SQLiteDatabase db = this.getReadableDatabase();

        String searchValue = "%" + searchText + "%";

        return db.rawQuery(
                "SELECT * FROM " + TABLE_INVENTORY +
                        " WHERE " + COLUMN_ITEM_NUMBER + " LIKE ? OR " +
                        COLUMN_ITEM_NAME + " LIKE ?",
                new String[]{searchValue, searchValue});
    }

    /**

     * Updates the quantity of an inventory item.
     */
    public boolean updateInventoryQuantity(String itemNumber,
                                           int newQuantity) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);

        int result =
                db.update(TABLE_INVENTORY,
                        values,
                        COLUMN_ITEM_NUMBER + "=?",
                        new String[]{itemNumber});

        return result > 0;
    }

    /**

     * Deletes an inventory item from the database.
     */
    public boolean deleteInventoryItem(String itemNumber) {

        SQLiteDatabase db = this.getWritableDatabase();

        int result =
                db.delete(TABLE_INVENTORY,
                        COLUMN_ITEM_NUMBER + "=?",
                        new String[]{itemNumber});

        return result > 0;
    }
}
