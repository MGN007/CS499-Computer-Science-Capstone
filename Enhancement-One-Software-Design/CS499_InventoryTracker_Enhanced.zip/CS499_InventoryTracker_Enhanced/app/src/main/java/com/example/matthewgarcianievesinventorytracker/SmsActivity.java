package com.example.matthewgarcianievesinventorytracker;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * SMS notification screen.
 * This screen requests SMS permission, saves a phone number,
 * and displays whether SMS alerts are enabled or denied.
 */
public class SmsActivity extends AppCompatActivity {

    // Request code used for SMS permission response
    private static final int SMS_PERMISSION_CODE = 100;

    // SharedPreferences file and key names
    public static final String PREFS_NAME = "SmsPrefs";
    public static final String PHONE_KEY = "phoneNumber";

    // UI elements
    EditText editPhoneNumber;
    Button buttonSMSPermission;
    TextView textPermissionStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load the SMS notification layout
        setContentView(R.layout.activity_sms);

        // Connect Java variables to XML controls
        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        buttonSMSPermission = findViewById(R.id.buttonSMSPermission);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);

        // Load saved phone number if one exists
        SharedPreferences preferences =
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        String savedPhoneNumber =
                preferences.getString(PHONE_KEY, "");

        editPhoneNumber.setText(savedPhoneNumber);

        // Check current permission status when screen opens
        checkSmsPermissionStatus();

        // Save phone number and request SMS permission
        buttonSMSPermission.setOnClickListener(v -> {

            String phoneNumber =
                    editPhoneNumber.getText().toString().trim();

            if (phoneNumber.isEmpty()) {
                Toast.makeText(
                        SmsActivity.this,
                        "Please enter a phone number",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Save phone number for future inventory alerts
            SharedPreferences.Editor editor =
                    preferences.edit();

            editor.putString(PHONE_KEY, phoneNumber);
            editor.apply();

            requestSmsPermission();
        });
    }

    /**
     * Checks whether SMS permission has already been granted.
     */
    private void checkSmsPermissionStatus() {

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            textPermissionStatus.setText("Permission Status: Granted");

        } else {

            textPermissionStatus.setText("Permission Status: Not Granted");
        }
    }

    /**
     * Requests SMS permission from the user.
     */
    private void requestSmsPermission() {

        ActivityCompat.requestPermissions(
                this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE);
    }

    /**
     * Handles the user's response to the SMS permission request.
     */
    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                textPermissionStatus.setText("Permission Status: Granted");

                Toast.makeText(
                        SmsActivity.this,
                        "SMS alerts enabled",
                        Toast.LENGTH_SHORT).show();

            } else {

                textPermissionStatus.setText("Permission Status: Denied");

                Toast.makeText(
                        SmsActivity.this,
                        "SMS alerts disabled",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}