package com.example.matthewgarcianievesinventorytracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Login screen for the Inventory Tracker application.
 * Allows the user to log in or create a new account.
 */
public class MainActivity extends AppCompatActivity {

    // Declare UI elements and database helper
    EditText editUsername;
    EditText editPassword;
    Button buttonLogin;
    Button buttonCreateAccount;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Connect Java variables to XML layout controls
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Check username and password when Login button is clicked
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean userExists =
                    databaseHelper.checkUser(username, password);

            if (userExists) {
                Toast.makeText(this,
                        "Login successful",
                        Toast.LENGTH_SHORT).show();

                Intent intent =
                        new Intent(MainActivity.this,
                                InventoryActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this,
                        "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Save new username and password when Create Account button is clicked
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this,
                        "Please enter username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean userAdded =
                    databaseHelper.addUser(username, password);

            if (userAdded) {
                Toast.makeText(this,
                        "Account created successfully",
                        Toast.LENGTH_SHORT).show();

                Intent intent =
                        new Intent(MainActivity.this,
                                InventoryActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(this,
                        "Account already exists",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}