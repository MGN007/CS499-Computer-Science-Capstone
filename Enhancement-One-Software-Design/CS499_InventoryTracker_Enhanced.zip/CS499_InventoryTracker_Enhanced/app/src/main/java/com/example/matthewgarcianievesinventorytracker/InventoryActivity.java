package com.example.matthewgarcianievesinventorytracker;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

/**
 * Inventory screen displayed after login.
 * Allows users to add, view, update, and delete inventory records.
 * Also provides access to SMS settings.
 */
public class InventoryActivity extends AppCompatActivity {

    // Buttons
    Button buttonSmsSettings;
    Button buttonAddItem;
    Button buttonUpdateQuantity;

    // Inventory entry fields
    EditText editItemNumber;
    EditText editItemName;
    EditText editQuantity;

    // Enhancement: Search controls for filtering inventory.
    EditText editSearchInventory;
    Button buttonSearchInventory;
    Button buttonClearSearch;

    // Table used to display inventory records
    TableLayout tableInventory;

    // Database helper
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Load inventory screen layout
        setContentView(R.layout.activity_inventory);

        // Create database helper object
        databaseHelper = new DatabaseHelper(this);

        // Connect inventory entry fields
        editItemNumber = findViewById(R.id.editItemNumber);
        editItemName = findViewById(R.id.editItemName);
        editQuantity = findViewById(R.id.editQuantity);

        // Connect buttons
        buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonUpdateQuantity = findViewById(R.id.buttonUpdateQuantity);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        // Enhancement: Connect inventory search controls.
        editSearchInventory = findViewById(R.id.editSearchInventory);
        buttonSearchInventory = findViewById(R.id.buttonSearchInventory);
        buttonClearSearch = findViewById(R.id.buttonClearSearch);

        // Connect inventory table
        tableInventory = findViewById(R.id.tableInventory);

        // Display inventory records when screen opens
        loadInventoryTable();

        // Enhancement: Search inventory by item number or item name.
        buttonSearchInventory.setOnClickListener(v -> {

            String searchText =
                    editSearchInventory.getText().toString().trim();

            if (searchText.isEmpty()) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Enter an item number or name to search",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            loadSearchResults(searchText);
        });

        // Enhancement: Clear search and display all inventory items.
        buttonClearSearch.setOnClickListener(v -> {
            editSearchInventory.setText("");
            loadInventoryTable();
        });

        // Add inventory item to database
        buttonAddItem.setOnClickListener(v -> {

            String itemNumber = editItemNumber.getText().toString().trim();
            String itemName = editItemName.getText().toString().trim();
            String quantityText = editQuantity.getText().toString().trim();

            // Validate user input
            if (itemNumber.isEmpty() || itemName.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Please complete all fields",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Enhancement: Added quantity validation to prevent invalid
            // or negative inventory values from being entered.
            int quantity;

            try {
                quantity = Integer.parseInt(quantityText);

                if (quantity < 0) {
                    Toast.makeText(
                            InventoryActivity.this,
                            "Quantity cannot be negative",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

            } catch (NumberFormatException e) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Quantity must be a valid number",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean inserted =
                    databaseHelper.addInventoryItem(itemNumber, itemName, quantity);

            if (inserted) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Inventory item added",
                        Toast.LENGTH_SHORT).show();

                // Enhancement: Send SMS alert when inventory is low or out of stock.
                if (quantity <= 5) {
                    sendInventorySmsAlert(itemNumber, quantity);
                }

                // Clear entry fields
                editItemNumber.setText("");
                editItemName.setText("");
                editQuantity.setText("");

                // Refresh inventory display
                loadInventoryTable();

            } else {
                Toast.makeText(
                        InventoryActivity.this,
                        "Unable to add item",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Update inventory quantity in database
        buttonUpdateQuantity.setOnClickListener(v -> {

            String itemNumber = editItemNumber.getText().toString().trim();
            String quantityText = editQuantity.getText().toString().trim();

            // Validate required fields for update
            if (itemNumber.isEmpty() || quantityText.isEmpty()) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Enter item number and new quantity",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Enhancement: Added quantity validation to prevent invalid
            // or negative values when updating inventory.
            int newQuantity;

            try {
                newQuantity = Integer.parseInt(quantityText);

                if (newQuantity < 0) {
                    Toast.makeText(
                            InventoryActivity.this,
                            "Quantity cannot be negative",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

            } catch (NumberFormatException e) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Quantity must be a valid number",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated =
                    databaseHelper.updateInventoryQuantity(itemNumber, newQuantity);

            if (updated) {
                Toast.makeText(
                        InventoryActivity.this,
                        "Inventory quantity updated",
                        Toast.LENGTH_SHORT).show();

                // Enhancement: Send SMS alert when inventory is low or out of stock.
                if (newQuantity <= 5) {
                    sendInventorySmsAlert(itemNumber, newQuantity);
                }

                // Clear fields after update
                editItemNumber.setText("");
                editItemName.setText("");
                editQuantity.setText("");

                // Refresh inventory display
                loadInventoryTable();

            } else {
                Toast.makeText(
                        InventoryActivity.this,
                        "Item number not found",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Open SMS settings screen
        buttonSmsSettings.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            InventoryActivity.this,
                            SmsActivity.class);

            startActivity(intent);
        });
    }

    /**
     * Sends an SMS alert when inventory is low or out of stock.
     * If permission is denied or no phone number is saved,
     * the rest of the app continues to function.
     */
    private void sendInventorySmsAlert(String itemNumber, int quantity) {

        // Check if SMS permission was granted
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(
                    InventoryActivity.this,
                    "SMS permission not granted",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        // Get saved phone number from SMS settings screen
        SharedPreferences preferences =
                getSharedPreferences(
                        SmsActivity.PREFS_NAME,
                        MODE_PRIVATE);

        String phoneNumber =
                preferences.getString(
                        SmsActivity.PHONE_KEY,
                        "");

        if (phoneNumber.isEmpty()) {

            Toast.makeText(
                    InventoryActivity.this,
                    "No phone number saved for SMS alerts",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        // Enhancement: SMS message identifies low-stock and out-of-stock items.
        String message;

        if (quantity == 0) {
            message =
                    "Inventory Alert: Item " +
                            itemNumber +
                            " is out of stock.";
        } else {
            message =
                    "Inventory Alert: Item " +
                            itemNumber +
                            " is low on stock. Current quantity: " +
                            quantity + ".";
        }

        SmsManager smsManager =
                SmsManager.getDefault();

        smsManager.sendTextMessage(
                phoneNumber,
                null,
                message,
                null,
                null);

        Toast.makeText(
                InventoryActivity.this,
                "SMS inventory alert sent",
                Toast.LENGTH_SHORT).show();
    }

    /**
     * Reads inventory items from the database
     * and displays them in the inventory table.
     */
    private void loadInventoryTable() {

        // Keep header row and remove old data rows
        int childCount = tableInventory.getChildCount();

        if (childCount > 1) {
            tableInventory.removeViews(1, childCount - 1);
        }

        Cursor cursor = databaseHelper.getAllInventoryItems();

        if (cursor.getCount() == 0) {
            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {

            String itemNumber = cursor.getString(1);
            String itemName = cursor.getString(2);
            int quantity = cursor.getInt(3);

            // Create new row
            TableRow row = new TableRow(this);

            // Item Number
            TextView itemNumberView = new TextView(this);
            itemNumberView.setText(itemNumber);
            itemNumberView.setPadding(8, 8, 8, 8);

            // Item Name
            TextView itemNameView = new TextView(this);
            itemNameView.setText(itemName);
            itemNameView.setPadding(8, 8, 8, 8);

            // Quantity
            TextView quantityView = new TextView(this);
            quantityView.setText(String.valueOf(quantity));
            quantityView.setPadding(8, 8, 8, 8);

            // Enhancement: Added inventory status based on quantity.
            TextView statusView = new TextView(this);

            if (quantity == 0) {
                statusView.setText("OUT OF STOCK");
            } else if (quantity <= 5) {
                statusView.setText("LOW STOCK");
            } else {
                statusView.setText("IN STOCK");
            }

            statusView.setPadding(8, 8, 8, 8);

            // Delete Button
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");

            // Delete selected inventory item
            deleteButton.setOnClickListener(v -> {

                boolean deleted =
                        databaseHelper.deleteInventoryItem(itemNumber);

                if (deleted) {
                    Toast.makeText(
                            InventoryActivity.this,
                            "Inventory item deleted",
                            Toast.LENGTH_SHORT).show();

                    // Refresh table after delete
                    loadInventoryTable();

                } else {
                    Toast.makeText(
                            InventoryActivity.this,
                            "Unable to delete item",
                            Toast.LENGTH_SHORT).show();
                }
            });

            // Add controls to row
            row.addView(itemNumberView);
            row.addView(itemNameView);
            row.addView(quantityView);
            row.addView(statusView);
            row.addView(deleteButton);

            // Add row to table
            tableInventory.addView(row);
        }

        cursor.close();
    }

    /**
     * Enhancement: Displays inventory records that match
     * an item number or item name search.
     */
    private void loadSearchResults(String searchText) {

        // Keep header row and remove old data rows
        int childCount = tableInventory.getChildCount();

        if (childCount > 1) {
            tableInventory.removeViews(1, childCount - 1);
        }

        Cursor cursor = databaseHelper.searchInventory(searchText);

        if (cursor.getCount() == 0) {
            Toast.makeText(
                    InventoryActivity.this,
                    "No matching inventory items found",
                    Toast.LENGTH_SHORT).show();

            cursor.close();
            return;
        }

        while (cursor.moveToNext()) {

            String itemNumber = cursor.getString(1);
            String itemName = cursor.getString(2);
            int quantity = cursor.getInt(3);

            TableRow row = new TableRow(this);

            TextView itemNumberView = new TextView(this);
            itemNumberView.setText(itemNumber);
            itemNumberView.setPadding(8, 8, 8, 8);

            TextView itemNameView = new TextView(this);
            itemNameView.setText(itemName);
            itemNameView.setPadding(8, 8, 8, 8);

            TextView quantityView = new TextView(this);
            quantityView.setText(String.valueOf(quantity));
            quantityView.setPadding(8, 8, 8, 8);

            TextView statusView = new TextView(this);

            if (quantity == 0) {
                statusView.setText("OUT OF STOCK");
            } else if (quantity <= 5) {
                statusView.setText("LOW STOCK");
            } else {
                statusView.setText("IN STOCK");
            }

            statusView.setPadding(8, 8, 8, 8);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");

            deleteButton.setOnClickListener(v -> {

                boolean deleted =
                        databaseHelper.deleteInventoryItem(itemNumber);

                if (deleted) {
                    Toast.makeText(
                            InventoryActivity.this,
                            "Inventory item deleted",
                            Toast.LENGTH_SHORT).show();

                    // Refresh the current search after deleting an item
                    loadSearchResults(searchText);

                } else {
                    Toast.makeText(
                            InventoryActivity.this,
                            "Unable to delete item",
                            Toast.LENGTH_SHORT).show();
                }
            });

            row.addView(itemNumberView);
            row.addView(itemNameView);
            row.addView(quantityView);
            row.addView(statusView);
            row.addView(deleteButton);

            tableInventory.addView(row);
        }

        cursor.close();
    }
}