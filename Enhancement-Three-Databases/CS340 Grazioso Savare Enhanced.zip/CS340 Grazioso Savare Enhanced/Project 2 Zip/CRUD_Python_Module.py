# CRUD_Python_Module.py
# Author: Matthew Garcia Nieves
# Description:
#     This module provides a Python interface for performing CRUD (Create, Read,
#     Update, Delete) operations on the Austin Animal Center MongoDB database.
#     It also includes specialized rescue-type query functions used by the
#     Project Two Dash dashboard for data filtering.

import os
from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """
    CRUD operations for the 'animals' collection in the AAC MongoDB database.

    This class encapsulates all database interactions so the dashboard and
    other client applications can access data cleanly and consistently.
    """

    def __init__(self):
        """
        Initialize the connection to MongoDB using authentication credentials.
        """

        # Connection configuration

        # Enhancement: Load database credentials from environment variables
        # instead of storing them directly in the source code.
        USER = os.getenv("AAC_DB_USER")
        PASS = os.getenv("AAC_DB_PASSWORD")
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Establish connection
        try:

            # Enhancement: Use credentials when they are provided.
            # Otherwise, connect to a local MongoDB server without authentication.
            if USER and PASS:
                self.client = MongoClient(
                    f'mongodb://{USER}:{PASS}@{HOST}:{PORT}'
                )
            else:
                self.client = MongoClient(
                    f'mongodb://{HOST}:{PORT}'
                )

            # Enhancement: Verify that the MongoDB server can actually be reached.
            self.client.admin.command("ping")

            self.database = self.client[DB]
            self.collection = self.database[COL]

            # Enhancement: Create database indexes after a successful connection.
            self._create_indexes()

        except Exception as e:
            print(f"Error connecting to MongoDB: {e}")
            self.client = None
            self.database = None
            self.collection = None

    # ----------------------------------------------------------------------
    # INTERNAL HELPER METHODS
    # ----------------------------------------------------------------------

    def _create_indexes(self):
        """
        Create indexes for fields commonly used by the rescue-type queries.
        These indexes improve database search performance as the collection grows.
        """
        if self.collection is None:
            return

        try:
            # Enhancement: Create a compound index for the fields used together
            # by the rescue-type database queries.
            self.collection.create_index(
                [
                    ("breed", 1),
                    ("sex_upon_outcome", 1),
                    ("age_upon_outcome_in_weeks", 1),
                ],
                name="rescue_filter_index",
            )
        except Exception as e:
            print(f"Error creating database indexes: {e}")

    def _get_next_rec_num(self):
        """
        Automatically generate an incrementing record number for new documents.
        If no previous record exists, start at 1.
        """
        try:
            last_record = self.collection.find_one(sort=[("rec_num", -1)])
            if last_record and "rec_num" in last_record:
                return last_record["rec_num"] + 1
            else:
                return 1
        except Exception:
            # On error, begin numbering at 1
            return 1

    def _validate_animal_data(self, data):
        """
        Validate animal data before it is added to the database.
        """

        # Enhancement: Reject missing or incorrectly formatted animal data
        # before attempting to store it in MongoDB.
        if not isinstance(data, dict):
            return False

        required_fields = [
            "animal_id",
            "animal_type",
            "breed",
            "sex_upon_outcome"
        ]

        for field in required_fields:
            if field not in data:
                return False

            if not isinstance(data[field], str):
                return False

            if not data[field].strip():
                return False

        # Age cannot be negative when it is provided.
        if "age_upon_outcome_in_weeks" in data:
            age = data["age_upon_outcome_in_weeks"]

            if not isinstance(age, (int, float)):
                return False

            if age < 0:
                return False

        return True

    # ----------------------------------------------------------------------
    # CRUD: CREATE
    # ----------------------------------------------------------------------

    def create(self, data):
        """
        Insert a new document into the collection.

        :param data: Dictionary representing an animal document.
        :return: True if insertion succeeded, False otherwise.
        """
        if self.collection is None:
            return False

        # Enhancement: Validate the animal record before inserting it.
        if not self._validate_animal_data(data):
            print("Invalid animal data. Record was not added.")
            return False

        # Add a rec_num automatically if not provided.
        if "rec_num" not in data:
            data["rec_num"] = self._get_next_rec_num()

        try:
            self.collection.insert_one(data)
            return True
        except Exception as e:
            print(f"Error creating animal record: {e}")
            return False

    # ----------------------------------------------------------------------
    # CRUD: READ
    # ----------------------------------------------------------------------

    def read(self, query):
        """
        Query the database and return matching documents.

        :param query: MongoDB query dictionary. Use {} for all documents.
        :return: List of matching documents.
        """
        if self.collection is None:
            return []

        # None → return all docs
        if query is None:
            query = {}

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception:
            return []

    # ----------------------------------------------------------------------
    # CRUD: UPDATE
    # ----------------------------------------------------------------------

    def update(self, query, new_values):
        """
        Update one or more documents that match the query.

        :param query: Dictionary specifying which documents to update.
        :param new_values: Dictionary containing field updates.
        :return: Number of modified documents.
        """
        if self.collection is None:
            return 0
        if not query or not new_values:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception:
            return 0

    # ----------------------------------------------------------------------
    # CRUD: DELETE
    # ----------------------------------------------------------------------

    def delete(self, query):
        """
        Delete one or more documents that match the query.

        :param query: Dictionary identifying documents to delete.
        :return: Number of deleted documents.
        """
        if self.collection is None:
            return 0
        if not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception:
            return 0

    # ----------------------------------------------------------------------
    # PROJECT TWO: RESCUE FILTER QUERIES
    # ----------------------------------------------------------------------

    def read_all(self):
        """
        Return the full dataset for the dashboard's initial load and reset.
        """
        return self.read({})

    def water_rescue(self):
        """
        Dogs suitable for WATER RESCUE.

        Criteria:
            - Breed: Labrador Retriever Mix, Chesapeake Bay Retriever, Newfoundland
            - Sex: Intact Female
            - Age: 26–156 weeks
        """
        query = {
            "$and": [
                {"breed": {"$in": [
                    "Labrador Retriever Mix",
                    "Chesapeake Bay Retriever",
                    "Newfoundland"
                ]}},
                {"sex_upon_outcome": "Intact Female"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        return self.read(query)

    def mountain_wilderness_rescue(self):
        """
        Dogs suitable for MOUNTAIN OR WILDERNESS RESCUE.

        Criteria:
            - Breed: German Shepherd, Alaskan Malamute, Old English Sheepdog,
                     Siberian Husky, Rottweiler
            - Sex: Intact Male
            - Age: 26–156 weeks
        """
        query = {
            "$and": [
                {"breed": {"$in": [
                    "German Shepherd",
                    "Alaskan Malamute",
                    "Old English Sheepdog",
                    "Siberian Husky",
                    "Rottweiler"
                ]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        return self.read(query)

    def disaster_or_individual_tracking(self):
        """
        Dogs suitable for DISASTER RESCUE or INDIVIDUAL TRACKING.

        Criteria:
            - Breed: Doberman Pinscher, German Shepherd, Golden Retriever,
                     Bloodhound, Rottweiler
            - Sex: Intact Male
            - Age: 20–300 weeks
        """
        query = {
            "$and": [
                {"breed": {"$in": [
                    "Doberman Pinscher",
                    "German Shepherd",
                    "Golden Retriever",
                    "Bloodhound",
                    "Rottweiler"
                ]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}}
            ]
        }
        return self.read(query)
        
    def rescue_summary(self):
        """
        Generate a summary of rescue candidates by breed using
        MongoDB's aggregation pipeline.
        """

        if self.collection is None:
            return []

        # Enhancement: Use MongoDB aggregation to create a report showing
        # the number of rescue candidates available for each breed.
        pipeline = [
            {
                "$match": {
                    "animal_type": "Dog",
                    "breed": {"$exists": True, "$ne": ""}
                }
            },
            {
                "$group": {
                    "_id": "$breed",
                    "candidate_count": {"$sum": 1},
                    "average_age_weeks": {
                        "$avg": "$age_upon_outcome_in_weeks"
                    }
                }
            },
            {
                "$sort": {
                    "candidate_count": -1
                }
            },
            {
                "$limit": 10
            }
        ]

        try:
            return list(self.collection.aggregate(pipeline))
        except Exception as e:
            print(f"Error generating rescue summary: {e}")
            return []