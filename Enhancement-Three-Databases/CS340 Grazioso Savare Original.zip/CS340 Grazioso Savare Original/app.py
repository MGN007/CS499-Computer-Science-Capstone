# app.py
# CS 340 – Grazioso Salvare Dashboard
# Author: Matthew Garcia Nieves

from dash import Dash, dcc, html, dash_table
from dash.dependencies import Input, Output
import dash_leaflet as dl
import plotly.express as px
import base64
import pandas as pd

# Import the CRUD module and AnimalShelter class
from CRUD_Python_Module import AnimalShelter

###########################
# Data Manipulation / Model
###########################

# Database credentials
username = "YOUR_MONGODB_USERNAME"
password = "YOUR_MONGODB_PASSWORD"

# Connect to database via CRUD Module
db = AnimalShelter(username, password)

# Initial load: get all records (for Reset / default view)
records_all = db.read_all()

# Convert to DataFrame
df = pd.DataFrame.from_records(records_all)

# Remove MongoDB _id field so DataTable doesn't choke on ObjectId
if "_id" in df.columns:
    df.drop(columns=["_id"], inplace=True)

#########################
# Dashboard Layout / View
#########################

app = Dash(__name__)

# --- Load Grazioso Salvare logo and encode as base64 ---
# Make sure "grazioso_logo.png" is in the same folder as this file,
# or update the filename below.
image_filename = "grazioso_logo.png"
encoded_image = base64.b64encode(open(image_filename, "rb").read())

app.layout = html.Div(
    children=[
        # ========= TOP BANNER: LOGO + TITLE + NAME =========
        html.Div(
            children=[
                # Logo with link to SNHU
                html.A(
                    html.Img(
                        src="data:image/png;base64,{}".format(encoded_image.decode()),
                        style={"height": "80px"},
                    ),
                    href="https://www.snhu.edu",
                    target="_blank",
                ),
                html.Div(
                    children=[
                        html.H1(
                            "Grazioso Salvare Rescue Dog Dashboard",
                            style={"marginBottom": "0"},
                        ),
                        html.H4(
                            "Dashboard created by Matthew Garcia Nieves",
                            style={"marginTop": "5px", "fontStyle": "italic"},
                        ),
                    ],
                    style={"marginLeft": "20px"},
                ),
            ],
            style={
                "display": "flex",
                "alignItems": "center",
                "padding": "10px",
                "borderBottom": "2px solid #ccc",
            },
        ),
        html.Hr(),

        # ========= INTERACTIVE FILTER OPTIONS =========
        html.Div(
            children=[
                html.Label(
                    "Rescue Type Filter:",
                    style={"fontWeight": "bold", "marginRight": "10px"},
                ),
                dcc.RadioItems(
                    id="filter-type",
                    options=[
                        {"label": "Water Rescue", "value": "water"},
                        {"label": "Mountain or Wilderness Rescue", "value": "mountain"},
                        {"label": "Disaster or Individual Tracking", "value": "disaster"},
                        {"label": "Reset (Show All)", "value": "reset"},
                    ],
                    value="reset",
                    inline=True,
                ),
            ],
            style={"padding": "10px 20px"},
        ),
        html.Hr(),

        # ========= INTERACTIVE DATA TABLE =========
        dash_table.DataTable(
            id="datatable-id",
            columns=[{"name": i, "id": i, "deletable": False, "selectable": True} for i in df.columns],
            data=df.to_dict("records"),
            page_size=10,
            sort_action="native",
            filter_action="native",
            row_selectable="single",
            selected_rows=[0],
            style_table={"overflowX": "auto", "maxHeight": "500px"},
            style_cell={
                "textAlign": "left",
                "padding": "5px",
                "fontFamily": "Arial",
                "fontSize": 12,
                "whiteSpace": "normal",
                "height": "auto",
            },
            style_header={"backgroundColor": "#f0f0f0", "fontWeight": "bold"},
        ),

        html.Br(),
        html.Hr(),

        # ========= ROW FOR PIE CHART + MAP =========
        html.Div(
            style={"display": "flex"},
            children=[
                html.Div(id="graph-id", style={"padding": "10px", "width": "50%"}),
                html.Div(id="map-id", style={"padding": "10px", "width": "50%"}),
            ],
        ),
    ]
)

#############################################
# Interaction Between Components / Controller
#############################################

@app.callback(Output("datatable-id", "data"), [Input("filter-type", "value")])
def update_dashboard(filter_type):
    """Update the DataTable data based on the selected rescue filter."""
    if filter_type == "water":
        records = db.water_rescue()
    elif filter_type == "mountain":
        records = db.mountain_wilderness_rescue()
    elif filter_type == "disaster":
        records = db.disaster_or_individual_tracking()
    else:
        records = db.read_all()

    dff = pd.DataFrame.from_records(records)
    if "_id" in dff.columns:
        dff.drop(columns=["_id"], inplace=True)

    return dff.to_dict("records")


@app.callback(Output("graph-id", "children"), [Input("datatable-id", "derived_virtual_data")])
def update_graphs(viewData):
    """Update the pie chart to reflect the currently visible data in the table."""
    if viewData is None or len(viewData) == 0:
        dff = df
    else:
        dff = pd.DataFrame.from_dict(viewData)

    fig = px.pie(dff, names="breed", title="Breed Distribution for Selected Rescue Filter")
    return [dcc.Graph(figure=fig)]


@app.callback(Output("datatable-id", "style_data_conditional"), [Input("datatable-id", "selected_columns")])
def update_styles(selected_columns):
    return [{"if": {"column_id": i}, "background_color": "#D2F3FF"} for i in (selected_columns or [])]


@app.callback(
    Output("map-id", "children"),
    [Input("datatable-id", "derived_virtual_data"), Input("datatable-id", "derived_virtual_selected_rows")],
)
def update_map(viewData, index):
    """Update the leaflet map to show the location of the selected animal."""
    if viewData is None or index is None or len(index) == 0:
        return []

    dff = pd.DataFrame.from_dict(viewData)
    row = index[0]

    return [
        dl.Map(
            style={"width": "1000px", "height": "500px"},
            center=[30.75, -97.48],
            zoom=10,
            children=[
                dl.TileLayer(id="base-layer-id"),
                dl.Marker(
                    position=[dff.iloc[row, 13], dff.iloc[row, 14]],
                    children=[
                        dl.Tooltip(dff.iloc[row, 4]),
                        dl.Popup([html.H1("Animal Name"), html.P(dff.iloc[row, 9])]),
                    ],
                ),
            ],
        )
    ]


if __name__ == "__main__":
    app.run(debug=True)
