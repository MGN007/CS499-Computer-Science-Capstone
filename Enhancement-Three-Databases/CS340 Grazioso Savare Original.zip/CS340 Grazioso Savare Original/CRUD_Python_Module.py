# CRUD_Python_Module.py
# Author: Matthew Garcia Nieves
# Description:
#     This module provides a Python interface for performing CRUD (Create, Read,
#     Update, Delete) operations on the Austin Animal Center MongoDB database.
#     It also includes specialized rescue-type query functions used by the
#     Project Two Dash dashboard for data filtering.

from pymongo import MongoClient
from bson.objectid import ObjectId


class AnimalShelter(object):
    """
    CRUD operations for the 'animals' collection in the AAC MongoDB database.

    This class encapsulates all database interactions so the dashboard and
    other client applications can access data cleanly and consistently.
    """

    def __init__(self, username='YOUR_MONGODB_USERNAME', password='YOUR_MONGODB_PASSWORD'):
        """
        Initialize the connection to MongoDB using authentication credentials.
        """

        # Connection configuration
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Establish connection
        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except Exception as e:
            print(f"Error connecting to MongoDB: {e}")
            self.client = None
            self.database = None
            self.collection = None

    # ----------------------------------------------------------------------
    # INTERNAL HELPER METHODS
    # ----------------------------------------------------------------------

    def _get_next_rec_num(self):
        """
        Automatically generate an incrementing record number for new documents.
        If no previous record exists, start at 1.
        """
        try:
            last_record = self.collection.find_one(sort=[("rec_num", -1)])
            if last_record and "rec_num" in last_record:
                return last_record["rec_num"] + 1
            else:
                return 1
        except Exception:
            # On error, begin numbering at 1
            return 1

    # ----------------------------------------------------------------------
    # CRUD: CREATE
    # ----------------------------------------------------------------------

    def create(self, data):
        """
        Insert a new document into the collection.

        :param data: Dictionary representing an animal document.
        :return: True if insertion succeeded, False otherwise.
        """
        if self.collection is None:
            return False

        if data is not None:
            # Add a rec_num automatically if not provided
            if "rec_num" not in data:
                data["rec_num"] = self._get_next_rec_num()

            try:
                self.collection.insert_one(data)
                return True
            except Exception:
                return False
        else:
            return False

    # ----------------------------------------------------------------------
    # CRUD: READ
    # ----------------------------------------------------------------------

    def read(self, query):
        """
        Query the database and return matching documents.

        :param query: MongoDB query dictionary. Use {} for all documents.
        :return: List of matching documents.
        """
        if self.collection is None:
            return []

        # None → return all docs
        if query is None:
            query = {}

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception:
            return []

    # ----------------------------------------------------------------------
    # CRUD: UPDATE
    # ----------------------------------------------------------------------

    def update(self, query, new_values):
        """
        Update one or more documents that match the query.

        :param query: Dictionary specifying which documents to update.
        :param new_values: Dictionary containing field updates.
        :return: Number of modified documents.
        """
        if self.collection is None:
            return 0
        if not query or not new_values:
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception:
            return 0

    # ----------------------------------------------------------------------
    # CRUD: DELETE
    # ----------------------------------------------------------------------

    def delete(self, query):
        """
        Delete one or more documents that match the query.

        :param query: Dictionary identifying documents to delete.
        :return: Number of deleted documents.
        """
        if self.collection is None:
            return 0
        if not query:
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception:
            return 0

    # ----------------------------------------------------------------------
    # PROJECT TWO: RESCUE FILTER QUERIES
    # ----------------------------------------------------------------------

    def read_all(self):
        """
        Return the full dataset for the dashboard's initial load and reset.
        """
        return self.read({})

    def water_rescue(self):
        """
        Dogs suitable for WATER RESCUE.

        Criteria:
            - Breed: Labrador Retriever Mix, Chesapeake Bay Retriever, Newfoundland
            - Sex: Intact Female
            - Age: 26–156 weeks
        """
        query = {
            "$and": [
                {"breed": {"$in": [
                    "Labrador Retriever Mix",
                    "Chesapeake Bay Retriever",
                    "Newfoundland"
                ]}},
                {"sex_upon_outcome": "Intact Female"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        return self.read(query)

    def mountain_wilderness_rescue(self):
        """
        Dogs suitable for MOUNTAIN OR WILDERNESS RESCUE.

        Criteria:
            - Breed: German Shepherd, Alaskan Malamute, Old English Sheepdog,
                     Siberian Husky, Rottweiler
            - Sex: Intact Male
            - Age: 26–156 weeks
        """
        query = {
            "$and": [
                {"breed": {"$in": [
                    "German Shepherd",
                    "Alaskan Malamute",
                    "Old English Sheepdog",
                    "Siberian Husky",
                    "Rottweiler"
                ]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156}}
            ]
        }
        return self.read(query)

    def disaster_or_individual_tracking(self):
        """
        Dogs suitable for DISASTER RESCUE or INDIVIDUAL TRACKING.

        Criteria:
            - Breed: Doberman Pinscher, German Shepherd, Golden Retriever,
                     Bloodhound, Rottweiler
            - Sex: Intact Male
            - Age: 20–300 weeks
        """
        query = {
            "$and": [
                {"breed": {"$in": [
                    "Doberman Pinscher",
                    "German Shepherd",
                    "Golden Retriever",
                    "Bloodhound",
                    "Rottweiler"
                ]}},
                {"sex_upon_outcome": "Intact Male"},
                {"age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300}}
            ]
        }
        return self.read(query)
