// ProjectTwo.cpp
// ABCU Advising Assistance Program
// Matthew Garcia Nieves 
// CS 300 Project Two
// 08/15/2025
//
// Single-file C++ console program that:
//  1) Loads course data from a CSV file into an in-memory hash table
//  2) Prints an alphanumeric list of all courses
//  3) Prints details for a specific course (title + prerequisites)
// No external headers or CSV parsers are required.

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>

using namespace std;

// -----------------------------
// Data Model
// -----------------------------
struct Course {
    string id;                     // e.g., "CSCI200"
    string title;                  // e.g., "Data Structures"
    vector<string> prereqIds;      // prerequisite course IDs (e.g., {"CSCI101"})
};

// Hash table to store all courses by ID
unordered_map<string, Course> gCatalog;

// -----------------------------
// Helpers
// -----------------------------

// Trim from both ends
static inline string trim(const string& s) {
    size_t start = 0;
    while (start < s.size() && isspace(static_cast<unsigned char>(s[start]))) start++;
    if (start == s.size()) return "";

    size_t end = s.size() - 1;
    while (end > start && isspace(static_cast<unsigned char>(s[end]))) end--;
    return s.substr(start, end - start + 1);
}

// Uppercase copy (to normalize course IDs and lookups)
static inline string toUpper(string s) {
    for (char& c : s) c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
    return s;
}

// Split a CSV line by commas (no quoted fields needed for this project�s input)
static vector<string> splitCSV(const string& line) {
    vector<string> out;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) out.push_back(trim(token));
    return out;
}

// Alphanumeric comparator for course IDs (keeps standard lexicographical order,
// which suits IDs like CSCI100, CSCI101, CSCI200, CSCI350, CSCI400, MATH201)
static bool courseIdLess(const string& a, const string& b) {
    return a < b;
}

// -----------------------------
// Loading & Validation
// -----------------------------

// Enhancement: Check that every prerequisite listed in the file
// actually exists as a course in the hash table.

bool validatePrerequisites(const unordered_map<string, Course>& catalog) {
    bool valid = true;

    for (const auto& entry : catalog) {
        const Course& course = entry.second;

        for (const string& prereqId : course.prereqIds) {
            if (catalog.find(prereqId) == catalog.end()) {
                cerr << "ERROR: Course " << course.id
                    << " requires missing prerequisite "
                    << prereqId << ".\n";
                valid = false;
            }
        }
    }

    return valid;
}

// Enhancement: Use depth-first search to detect circular
// prerequisite relationships between courses.

bool hasPrerequisiteCycle(
    const string& courseId,
    const unordered_map<string, Course>& catalog,
    unordered_map<string, int>& visitState) {

    // 1 means this course is currently being visited.
    // Finding it again means there is a cycle.

    if (visitState[courseId] == 1) {
        return true;
    }

    // 2 means this course has already been completely checked.

    if (visitState[courseId] == 2) {
        return false;
    }

    visitState[courseId] = 1;

    const Course& course = catalog.at(courseId);

    for (const string& prereqId : course.prereqIds) {
        if (hasPrerequisiteCycle(prereqId, catalog, visitState)) {
            return true;
        }
    }

    visitState[courseId] = 2;
    return false;
}

// Enhancement: Check the entire catalog for circular prerequisite relationships.

bool validateNoCycles(const unordered_map<string, Course>& catalog) {
    unordered_map<string, int> visitState;

    for (const auto& entry : catalog) {
        const string& courseId = entry.first;

        if (hasPrerequisiteCycle(courseId, catalog, visitState)) {
            cerr << "ERROR: Circular prerequisite relationship detected involving "
                << courseId << ".\n";
            return false;
        }
    }

    return true;
}

// -----------------------------
// Enhancement: Course Planning Algorithm
// -----------------------------

// Enhancement: Use depth-first search to place prerequisites
// before the courses that depend on them.

void buildCourseOrder(
    const string& courseId,
    const unordered_map<string, Course>& catalog,
    unordered_map<string, bool>& visited,
    vector<string>& courseOrder) {

    if (visited[courseId]) {
        return;
    }

    visited[courseId] = true;

    const Course& course = catalog.at(courseId);

    // Visit prerequisites before adding the current course.
    for (const string& prereqId : course.prereqIds) {
        buildCourseOrder(prereqId, catalog, visited, courseOrder);
    }

    courseOrder.push_back(courseId);
}

// Enhancement: Generate and display a valid course order
// based on prerequisite relationships.

void printRecommendedCourseOrder() {
    if (gCatalog.empty()) {
        cout << "No data loaded. Please load the data structure first.\n";
        return;
    }

    unordered_map<string, bool> visited;
    vector<string> courseOrder;

    // Build an order for every course in the catalog.
    for (const auto& entry : gCatalog) {
        buildCourseOrder(entry.first, gCatalog, visited, courseOrder);
    }

    cout << "\nRecommended Course Order:\n";

    for (const string& courseId : courseOrder) {
        const Course& course = gCatalog.at(courseId);
        cout << course.id << ", " << course.title << '\n';
    }

    cout << endl;
}

bool loadCoursesFromFile(const string& filePath) {
    ifstream in(filePath);
    if (!in.is_open()) {
        cerr << "ERROR: Could not open file '" << filePath << "'.\n";
        return false;
    }

    unordered_map<string, Course> tmp; // build in temp; only swap on success
    string line;
    size_t lineNo = 0;

    while (getline(in, line)) {
        ++lineNo;
        string raw = trim(line);
        if (raw.empty()) continue;              // skip blanks
        if (raw[0] == '#') continue;            // allow comments

        vector<string> cols = splitCSV(raw);
        if (cols.size() < 2) {
            cerr << "WARNING: Line " << lineNo
                << " has fewer than 2 columns (courseNumber,name). Skipped.\n";
            continue;
        }

        string id = toUpper(cols[0]);
        string title = cols[1];

        Course c;
        c.id = id;
        c.title = title;

        // Collect prerequisites if present
        for (size_t i = 2; i < cols.size(); ++i) {
            string pre = toUpper(cols[i]);
            if (!pre.empty()) c.prereqIds.push_back(pre);
        }

        // Insert/update course entry
        auto it = tmp.find(id);
        if (it == tmp.end()) {
            tmp[id] = c;
        }
        else {
            // If the course shows up more than once, last one wins; warn user.
            cerr << "WARNING: Duplicate definition for '" << id
                << "' at line " << lineNo << " (overwriting previous).\n";
            tmp[id] = c;
        }
    }

    // Enhancement: Validate prerequisite relationships before accepting the catalog.
    if (!validatePrerequisites(tmp)) {
        cerr << "ERROR: Course data contains invalid prerequisite references.\n";
        return false;
    }

    // Enhancement: Reject course data that contains circular prerequisites.
    if (!validateNoCycles(tmp)) {
        cerr << "ERROR: Course data contains a circular prerequisite relationship.\n";
        return false;
    }

    // If validation passed, move the temporary catalog into the global catalog.
    gCatalog.swap(tmp);
    cout << "Loaded " << gCatalog.size() << " course(s)." << endl;
    return true;
}

// -----------------------------
// Printing Utilities
// -----------------------------

void printCourseList() {
    if (gCatalog.empty()) {
        cout << "No data loaded. Please load the data structure first.\n";
        return;
    }

    vector<string> ids;
    ids.reserve(gCatalog.size());
    for (const auto& kv : gCatalog) ids.push_back(kv.first);

    sort(ids.begin(), ids.end(), courseIdLess);

    cout << "Here is a sample schedule:" << endl << endl;
    for (const string& id : ids) {
        const Course& c = gCatalog[id];
        cout << c.id << ", " << c.title << '\n';
    }
    cout << endl;
}

void printSingleCourse(const string& rawId) {
    if (gCatalog.empty()) {
        cout << "No data loaded. Please load the data structure first.\n";
        return;
    }

    string id = toUpper(trim(rawId));
    auto it = gCatalog.find(id);
    if (it == gCatalog.end()) {
        cout << "Course '" << rawId << "' was not found.\n";
        return;
    }

    const Course& c = it->second;
    cout << c.id << ", " << c.title << '\n';

    if (c.prereqIds.empty()) {
        cout << "Prerequisites: None\n";
        return;
    }

    cout << "Prerequisites: ";
    for (size_t i = 0; i < c.prereqIds.size(); ++i) {
        const string& pid = c.prereqIds[i];
        auto pIt = gCatalog.find(pid);
        if (pIt != gCatalog.end()) {
            cout << pIt->second.id;
            cout << " (" << pIt->second.title << ")";
        }
        else {
            // If a prerequisite is referenced but missing from the file
            cout << pid << " (missing)";
        }
        if (i + 1 < c.prereqIds.size()) cout << ", ";
    }
    cout << '\n';
}

// -----------------------------
// Menu
// -----------------------------
void printMenu() {
    cout << "Welcome to the course planner." << endl << endl;
    cout << "  1. Load Data Structure." << endl;
    cout << "  2. Print Course List." << endl;
    cout << "  3. Print Course." << endl;
    cout << "  4. Print Recommended Course Order." << endl;
    cout << "  9. Exit" << endl << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    bool running = true;

    while (running) {
        printMenu();
        cout << "What would you like to do? ";

        string choiceRaw;
        if (!getline(cin, choiceRaw)) break;
        string choice = trim(choiceRaw);

        if (choice == "1") {
            cout << "Enter the file name to load: ";
            string path;
            if (!getline(cin, path)) break;
            path = trim(path);
            if (path.empty()) {
                cout << "ERROR: File name cannot be empty.\n";
                continue;
            }
            loadCoursesFromFile(path);

        }
        else if (choice == "2") {
            printCourseList();

        }
        else if (choice == "3") {
            cout << "What course do you want to know about? ";
            string id;
            if (!getline(cin, id)) break;
            printSingleCourse(id);

        }
        else if (choice == "4") {
            printRecommendedCourseOrder();

        }
        else if (choice == "9") {
            cout << "Thank you for using the course planner!" << endl;
            running = false;

        }
        else {
            cout << choice << " is not a valid option." << endl << endl;
        }
    }

    return 0;
}
