// ProjectTwo.cpp
// ABCU Advising Assistance Program
// Matthew Garcia Nieves 
// CS 300 Project Two
// 08/15/2025
//
// Single-file C++ console program that:
//  1) Loads course data from a CSV file into an in-memory hash table
//  2) Prints an alphanumeric list of all courses
//  3) Prints details for a specific course (title + prerequisites)
// No external headers or CSV parsers are required.

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <cctype>

using namespace std;

// -----------------------------
// Data Model
// -----------------------------
struct Course {
    string id;                     // e.g., "CSCI200"
    string title;                  // e.g., "Data Structures"
    vector<string> prereqIds;      // prerequisite course IDs (e.g., {"CSCI101"})
};

// Hash table to store all courses by ID
unordered_map<string, Course> gCatalog;

// -----------------------------
// Helpers
// -----------------------------

// Trim from both ends
static inline string trim(const string& s) {
    size_t start = 0;
    while (start < s.size() && isspace(static_cast<unsigned char>(s[start]))) start++;
    if (start == s.size()) return "";

    size_t end = s.size() - 1;
    while (end > start && isspace(static_cast<unsigned char>(s[end]))) end--;
    return s.substr(start, end - start + 1);
}

// Uppercase copy (to normalize course IDs and lookups)
static inline string toUpper(string s) {
    for (char& c : s) c = static_cast<char>(toupper(static_cast<unsigned char>(c)));
    return s;
}

// Split a CSV line by commas (no quoted fields needed for this project�s input)
static vector<string> splitCSV(const string& line) {
    vector<string> out;
    string token;
    stringstream ss(line);
    while (getline(ss, token, ',')) out.push_back(trim(token));
    return out;
}

// Alphanumeric comparator for course IDs (keeps standard lexicographical order,
// which suits IDs like CSCI100, CSCI101, CSCI200, CSCI350, CSCI400, MATH201)
static bool courseIdLess(const string& a, const string& b) {
    return a < b;
}

// -----------------------------
// Loading & Validation
// -----------------------------
bool loadCoursesFromFile(const string& filePath) {
    ifstream in(filePath);
    if (!in.is_open()) {
        cerr << "ERROR: Could not open file '" << filePath << "'.\n";
        return false;
    }

    unordered_map<string, Course> tmp; // build in temp; only swap on success
    string line;
    size_t lineNo = 0;

    while (getline(in, line)) {
        ++lineNo;
        string raw = trim(line);
        if (raw.empty()) continue;              // skip blanks
        if (raw[0] == '#') continue;            // allow comments

        vector<string> cols = splitCSV(raw);
        if (cols.size() < 2) {
            cerr << "WARNING: Line " << lineNo
                << " has fewer than 2 columns (courseNumber,name). Skipped.\n";
            continue;
        }

        string id = toUpper(cols[0]);
        string title = cols[1];

        Course c;
        c.id = id;
        c.title = title;

        // Collect prerequisites if present
        for (size_t i = 2; i < cols.size(); ++i) {
            string pre = toUpper(cols[i]);
            if (!pre.empty()) c.prereqIds.push_back(pre);
        }

        // Insert/update course entry
        auto it = tmp.find(id);
        if (it == tmp.end()) {
            tmp[id] = c;
        }
        else {
            // If the course shows up more than once, last one wins; warn user.
            cerr << "WARNING: Duplicate definition for '" << id
                << "' at line " << lineNo << " (overwriting previous).\n";
            tmp[id] = c;
        }
    }

    // If we got here, load was fine; move into global catalog
    gCatalog.swap(tmp);
    cout << "Loaded " << gCatalog.size() << " course(s)." << endl;
    return true;
}

// -----------------------------
// Printing Utilities
// -----------------------------
void printCourseList() {
    if (gCatalog.empty()) {
        cout << "No data loaded. Please load the data structure first.\n";
        return;
    }

    vector<string> ids;
    ids.reserve(gCatalog.size());
    for (const auto& kv : gCatalog) ids.push_back(kv.first);

    sort(ids.begin(), ids.end(), courseIdLess);

    cout << "Here is a sample schedule:" << endl << endl;
    for (const string& id : ids) {
        const Course& c = gCatalog[id];
        cout << c.id << ", " << c.title << '\n';
    }
    cout << endl;
}

void printSingleCourse(const string& rawId) {
    if (gCatalog.empty()) {
        cout << "No data loaded. Please load the data structure first.\n";
        return;
    }

    string id = toUpper(trim(rawId));
    auto it = gCatalog.find(id);
    if (it == gCatalog.end()) {
        cout << "Course '" << rawId << "' was not found.\n";
        return;
    }

    const Course& c = it->second;
    cout << c.id << ", " << c.title << '\n';

    if (c.prereqIds.empty()) {
        cout << "Prerequisites: None\n";
        return;
    }

    cout << "Prerequisites: ";
    for (size_t i = 0; i < c.prereqIds.size(); ++i) {
        const string& pid = c.prereqIds[i];
        auto pIt = gCatalog.find(pid);
        if (pIt != gCatalog.end()) {
            cout << pIt->second.id;
            cout << " (" << pIt->second.title << ")";
        }
        else {
            // If a prerequisite is referenced but missing from the file
            cout << pid << " (missing)";
        }
        if (i + 1 < c.prereqIds.size()) cout << ", ";
    }
    cout << '\n';
}

// -----------------------------
// Menu
// -----------------------------
void printMenu() {
    cout << "Welcome to the course planner." << endl << endl;
    cout << "  1. Load Data Structure." << endl;
    cout << "  2. Print Course List." << endl;
    cout << "  3. Print Course." << endl;
    cout << "  9. Exit" << endl << endl;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    bool running = true;

    while (running) {
        printMenu();
        cout << "What would you like to do? ";

        string choiceRaw;
        if (!getline(cin, choiceRaw)) break;
        string choice = trim(choiceRaw);

        if (choice == "1") {
            cout << "Enter the file name to load: ";
            string path;
            if (!getline(cin, path)) break;
            path = trim(path);
            if (path.empty()) {
                cout << "ERROR: File name cannot be empty.\n";
                continue;
            }
            loadCoursesFromFile(path);

        }
        else if (choice == "2") {
            printCourseList();

        }
        else if (choice == "3") {
            cout << "What course do you want to know about? ";
            string id;
            if (!getline(cin, id)) break;
            printSingleCourse(id);

        }
        else if (choice == "9") {
            cout << "Thank you for using the course planner!" << endl;
            running = false;

        }
        else {
            cout << choice << " is not a valid option." << endl << endl;
        }
    }

    return 0;
}
